@section('name')
    <h2>Tambah Nilai</h2>
@endsection
@section('content')
<h2>Tambah Nilai</h2>
@if (session('error'))
<p>class="alert alert-danger">{{ session('error') }}</p>
@endif

<form action="form" action="/nilai-raport/store" method="post">
@csrf
<table>
    <tr class="position">
        <td>
           <label for="siswa_id">Nama siswa</label>
        </td>
        <td>
            <select name="siswa_id" id="siswa_id">
                <option value="">-- Pilih Siswa --</option>
                @foreach ($siswa as $data)
                    <option value="{{ $data->id }}">{{ $data->nama_siswa }}</option>
                @endforeach
            </select>
        </td>
    </tr>
    
</table>
</form>
@endsection