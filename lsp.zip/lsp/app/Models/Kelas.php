<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kelas extends Model
{
    use HasFactory;
    protected $table = 'kelas';
    protected $guarded = ['id'];
    protected $fillable = ['nama_kelas'];

    public function walas()
    {
        return $this->hasMany(Walas::class, 'kelas_id');
    }
}

