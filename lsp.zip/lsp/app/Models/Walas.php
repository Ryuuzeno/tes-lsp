<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Walas extends Model
{
    use HasFactory;
    protected $table = 'walas';
    protected $guarded = ['id'];
    protected $fillable = ['nig','nama_walas','kelas_id','password'];

    public function kelas()
    {
        return $this->belongsTo(Kelas::class);
    }

    public function nilai()
    {
        return $this->hasOne(Nilai::class);
    }
}
