<?php
namespace App\Http\Controllers;

use App\Models\Kelas;
use App\Models\Nilai;
use App\Models\Siswa;
use App\Models\Walas;
use Illuminate\Http\Request;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\Hash;

class NilaiController extends Controller
{
    
    public function index()
    {
        $walas = Walas::find(session('id'));

        if(!$walas) {
            return back()->with('error', 'data Walas tidak ditemukan.');
        }

        $data_nilai = Nilai::whereHas('siswa', function ($query) use ($walas) {
            $query->where('kelas_id', $walas->kelas_id);
        })->with('siswa')->get();
        $kelas = Kelas::where('id', session('id'))->first();

        return view('nilai.index', compact('data_nilai', 'kelas'));
    }

    public function create(){
        $walas = Walas::find(session('id'));
        $nilai = Nilai::pluck('siswa_id');

        $siswa = Siswa::where('kelas_id', $walas->kelas_id)->whereNotIn('id', $nilai)->get();

        return view('nilai.create',[
            'siswa' => $siswa
        ]);
    }

    public function show()
    {
        $nilai = Nilai::with('siswa')
            ->where('siswa_id', session('id'))
            ->first();

        if (!$nilai) {
            return back()->with('error', 'Data nilai belum ditemukan.');
        }

        return view('nilai.show', compact('nilai'));
    }
}


?>